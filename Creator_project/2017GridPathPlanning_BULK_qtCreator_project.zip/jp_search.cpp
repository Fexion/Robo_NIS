#include "jp_search.h"

JP_Search::~JP_Search()
{
}

std::list<Node> JP_Search::findSuccessors(Node curNode, const Map &map, const EnvironmentOptions &options)
{
    std::list<Node> successors;
    //need to implement
    return successors;
}

void JP_Search::makePrimaryPath(Node curNode)
{
    //need to implement
}

void JP_Search::makeSecondaryPath()
{
    //need to implement
}
