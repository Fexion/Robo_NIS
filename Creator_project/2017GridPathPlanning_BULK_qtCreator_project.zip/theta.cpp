#include "theta.h"
Theta::~Theta()
{
}

bool Theta::lineOfSight(int i1, int j1, int i2, int j2, const Map &map, bool cutcorners)
{
    //need to implement
    return true;
}

Node Theta::resetParent(Node current, Node parent, const Map &map, const EnvironmentOptions &options )
{
    //need to implement
    return current;
}

void Theta::makeSecondaryPath()
{
    //need to implement
}

void Theta::makePrimaryPath(Node curNode)
{
    //need to implement
}
