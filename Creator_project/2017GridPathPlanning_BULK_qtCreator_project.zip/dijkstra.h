#ifndef DIJKSTRA_H
#define DIJKSTRA_H
#include "astar.h"

class Dijkstra : public Astar
{
    public:
        Dijkstra();
};
#endif
