#include "dijkstra.h"

Dijkstra::Dijkstra() : Astar(0, CN_SP_BT_GMAX) {}

